# py_example.py

from sklearn import linear_model
reg_py = linear_model.LinearRegression()

import pandas 
def read_flights(file):
  flights = pandas.read_csv(file)
  flights = flights[flights['dest'] == "ORD"]
  flights = flights[['carrier', 'dep_delay', 'arr_delay']]
  flights = flights.dropna()
  return flights

"""
# in RStudio
library(reticulate)

py_install(packages="pandas", "scikit-learn")

source_python("d:/rpy2_pgm/py_example.py")
flights <- read_flights("c:/data/pydata/flights.csv")

library(ggplot2)
# library(ggplot2, lib.loc="C:\Users\USER\AppData\Local\Temp\RtmpY9deXj\downloaded_packages")

ggplot(flights, aes(carrier, arr_delay)) + geom_point() + geom_jitter()
"""

# Fit model 

reg_py$fit(X = mtcars[,-1], y = mtcars$mpg)
## LinearRegression(copy_X=True, fit_intercept=True, n_jobs=None, normalize=False)
# Show coefficients
data.frame(var = c("Intercept", names(mtcars)[-1]), 
           python_coef = c(linreg_python$intercept_, linreg_python$coef_))



# Fit model and show coefficients from R
fit = lm(mpg ~ ., data = mtcars)
data.frame(R_coef = coef(fit))

